let cart = [];

function updateCart() {
  const cartIcon = document.getElementById("cart-icon");
  const cartItems = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");

  cartIcon.textContent = `Cart (${cart.length})`;

  cartItems.innerHTML = '';
  let total = 0;

  cart.forEach(item => {
    let li = document.createElement("li");
    li.textContent = `${item.name} - $${item.price}`;
    cartItems.appendChild(li);
    total += item.price;
  });

  cartTotal.textContent = total.toFixed(2);
}

function addToCart(name, price) {
  cart.push({ name, price });
  updateCart();
}

document.getElementById("cart-icon").addEventListener("click", () => {
  const dropdown = document.getElementById("cart-dropdown");
  dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
});

document.getElementById("checkout-button").addEventListener("click", () => {
  alert("Proceeding to checkout...");
  document.getElementById("cart-dropdown").style.display = "none";
});

document.querySelectorAll(".product button").forEach(button => {
  button.addEventListener("click", (e) => {
    const product = e.target.closest(".product");
    const name = product.querySelector("h3").textContent;
    const price = parseFloat(product.querySelector("p").textContent.replace('$', ''));
    addToCart(name, price);
  });
});
